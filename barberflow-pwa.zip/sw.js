const CACHE_NAME = 'barberflow-v1';

const ASSETS_TO_CACHE = [
  '/Barberflow/',
  '/Barberflow/index.html',
  '/Barberflow/manifest.json',
  '/Barberflow/icon-192.png',
  '/Barberflow/icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS_TO_CACHE))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.map(key => {
        if (key !== CACHE_NAME) return caches.delete(key);
      }))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then(cached => {
      return cached || fetch(event.request).then(response => {
        return response;
      }).catch(() => caches.match('/Barberflow/index.html'));
    })
  );
});
